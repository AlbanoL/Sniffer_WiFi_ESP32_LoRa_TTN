#ifndef _BEACON_ARRAY_H
#define _BEACON_ARRAY_H

std::array<uint64_t, 0xff>::iterator it;

std::array<uint64_t, 0xff> beacons = {0x0000010203040506, 0x0000aabbccddeeff,
                                      0x0000112233445566};

#endif